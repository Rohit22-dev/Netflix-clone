import React from "react";

const index = () => {
  return <div className="text-3xl text-lime-600">NetFlix</div>;
};

export default index;
