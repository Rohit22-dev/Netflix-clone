import React from "react";

const profile = () => {
  return <div className="text-white">Profile</div>;
};

export default profile;
